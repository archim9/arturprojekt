@extends('master')
@section('content')
<h2>Artur Brzózka gr.04 IWB</h2>
@stop